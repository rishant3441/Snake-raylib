# raylib for Code::Blocks
**by D3nX**
<br/>
Hey! Here it is a project template to use with `Code::Blocks` =)
<br/><br/>
First, you need to download the [raylib installer](https://www.raylib.com) and run it. It will install raylib with the compiler.
<br/><br/>
Then, download the template, and open the project with `Code::Blocks`.

Before running the template, make sure following set the raylib compiler for the IDE as show below:
<br>
![Compiler Settings](compiler_settings.png)
<br/>
Finally, you can run the program and enjoy raylib running on `Code::Blocks`!
<br /><br />
Hope it helped you =)
